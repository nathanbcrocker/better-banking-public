package io.swagger.api;

import io.swagger.model.OBErrorResponse1;
import io.swagger.model.OBReadConsent1;
import io.swagger.model.OBReadConsentResponse1;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.constraints.*;
import javax.validation.Valid;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.List;
import java.util.Map;

@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2021-04-23T02:01:12.183Z[GMT]")
@RestController
public class AccountAccessConsentsApiController implements AccountAccessConsentsApi {

    private static final Logger log = LoggerFactory.getLogger(AccountAccessConsentsApiController.class);

    private final ObjectMapper objectMapper;

    private final HttpServletRequest request;

    @org.springframework.beans.factory.annotation.Autowired
    public AccountAccessConsentsApiController(ObjectMapper objectMapper, HttpServletRequest request) {
        this.objectMapper = objectMapper;
        this.request = request;
    }

    public ResponseEntity<OBReadConsentResponse1> createAccountAccessConsents(@Parameter(in = ParameterIn.HEADER, description = "An Authorisation Token as per https://tools.ietf.org/html/rfc6750" ,required=true,schema=@Schema()) @RequestHeader(value="Authorization", required=true) String authorization,@Parameter(in = ParameterIn.DEFAULT, description = "Default", required=true, schema=@Schema()) @Valid @RequestBody OBReadConsent1 body,@Parameter(in = ParameterIn.HEADER, description = "The time when the PSU last logged in with the TPP.  All dates in the HTTP headers are represented as RFC 7231 Full Dates. An example is below:  Sun, 10 Sep 2017 19:43:31 UTC" ,schema=@Schema()) @RequestHeader(value="x-fapi-auth-date", required=false) String xFapiAuthDate,@Parameter(in = ParameterIn.HEADER, description = "The PSU's IP address if the PSU is currently logged in with the TPP." ,schema=@Schema()) @RequestHeader(value="x-fapi-customer-ip-address", required=false) String xFapiCustomerIpAddress,@Parameter(in = ParameterIn.HEADER, description = "An RFC4122 UID used as a correlation id." ,schema=@Schema()) @RequestHeader(value="x-fapi-interaction-id", required=false) String xFapiInteractionId,@Parameter(in = ParameterIn.HEADER, description = "Indicates the user-agent that the PSU is using." ,schema=@Schema()) @RequestHeader(value="x-customer-user-agent", required=false) String xCustomerUserAgent) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<OBReadConsentResponse1>(objectMapper.readValue("{\n  \"Meta\" : {\n    \"FirstAvailableDateTime\" : \"2000-01-23T04:56:07.000+00:00\",\n    \"TotalPages\" : 0\n  },\n  \"Risk\" : { },\n  \"Links\" : {\n    \"Last\" : \"http://example.com/aeiou\",\n    \"Prev\" : \"http://example.com/aeiou\",\n    \"Next\" : \"http://example.com/aeiou\",\n    \"Self\" : \"http://example.com/aeiou\",\n    \"First\" : \"http://example.com/aeiou\"\n  },\n  \"Data\" : {\n    \"Status\" : \"Authorised\",\n    \"StatusUpdateDateTime\" : \"2000-01-23T04:56:07.000+00:00\",\n    \"CreationDateTime\" : \"2000-01-23T04:56:07.000+00:00\",\n    \"TransactionToDateTime\" : \"2000-01-23T04:56:07.000+00:00\",\n    \"ExpirationDateTime\" : \"2000-01-23T04:56:07.000+00:00\",\n    \"Permissions\" : [ \"ReadAccountsBasic\", \"ReadAccountsBasic\" ],\n    \"ConsentId\" : \"ConsentId\",\n    \"TransactionFromDateTime\" : \"2000-01-23T04:56:07.000+00:00\"\n  }\n}", OBReadConsentResponse1.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<OBReadConsentResponse1>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<OBReadConsentResponse1>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<Void> deleteAccountAccessConsentsConsentId(@Parameter(in = ParameterIn.PATH, description = "ConsentId", required=true, schema=@Schema()) @PathVariable("ConsentId") String consentId,@Parameter(in = ParameterIn.HEADER, description = "An Authorisation Token as per https://tools.ietf.org/html/rfc6750" ,required=true,schema=@Schema()) @RequestHeader(value="Authorization", required=true) String authorization,@Parameter(in = ParameterIn.HEADER, description = "The time when the PSU last logged in with the TPP.  All dates in the HTTP headers are represented as RFC 7231 Full Dates. An example is below:  Sun, 10 Sep 2017 19:43:31 UTC" ,schema=@Schema()) @RequestHeader(value="x-fapi-auth-date", required=false) String xFapiAuthDate,@Parameter(in = ParameterIn.HEADER, description = "The PSU's IP address if the PSU is currently logged in with the TPP." ,schema=@Schema()) @RequestHeader(value="x-fapi-customer-ip-address", required=false) String xFapiCustomerIpAddress,@Parameter(in = ParameterIn.HEADER, description = "An RFC4122 UID used as a correlation id." ,schema=@Schema()) @RequestHeader(value="x-fapi-interaction-id", required=false) String xFapiInteractionId,@Parameter(in = ParameterIn.HEADER, description = "Indicates the user-agent that the PSU is using." ,schema=@Schema()) @RequestHeader(value="x-customer-user-agent", required=false) String xCustomerUserAgent) {
        String accept = request.getHeader("Accept");
        return new ResponseEntity<Void>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<OBReadConsentResponse1> getAccountAccessConsentsConsentId(@Parameter(in = ParameterIn.PATH, description = "ConsentId", required=true, schema=@Schema()) @PathVariable("ConsentId") String consentId,@Parameter(in = ParameterIn.HEADER, description = "An Authorisation Token as per https://tools.ietf.org/html/rfc6750" ,required=true,schema=@Schema()) @RequestHeader(value="Authorization", required=true) String authorization,@Parameter(in = ParameterIn.HEADER, description = "The time when the PSU last logged in with the TPP.  All dates in the HTTP headers are represented as RFC 7231 Full Dates. An example is below:  Sun, 10 Sep 2017 19:43:31 UTC" ,schema=@Schema()) @RequestHeader(value="x-fapi-auth-date", required=false) String xFapiAuthDate,@Parameter(in = ParameterIn.HEADER, description = "The PSU's IP address if the PSU is currently logged in with the TPP." ,schema=@Schema()) @RequestHeader(value="x-fapi-customer-ip-address", required=false) String xFapiCustomerIpAddress,@Parameter(in = ParameterIn.HEADER, description = "An RFC4122 UID used as a correlation id." ,schema=@Schema()) @RequestHeader(value="x-fapi-interaction-id", required=false) String xFapiInteractionId,@Parameter(in = ParameterIn.HEADER, description = "Indicates the user-agent that the PSU is using." ,schema=@Schema()) @RequestHeader(value="x-customer-user-agent", required=false) String xCustomerUserAgent) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<OBReadConsentResponse1>(objectMapper.readValue("{\n  \"Meta\" : {\n    \"FirstAvailableDateTime\" : \"2000-01-23T04:56:07.000+00:00\",\n    \"TotalPages\" : 0\n  },\n  \"Risk\" : { },\n  \"Links\" : {\n    \"Last\" : \"http://example.com/aeiou\",\n    \"Prev\" : \"http://example.com/aeiou\",\n    \"Next\" : \"http://example.com/aeiou\",\n    \"Self\" : \"http://example.com/aeiou\",\n    \"First\" : \"http://example.com/aeiou\"\n  },\n  \"Data\" : {\n    \"Status\" : \"Authorised\",\n    \"StatusUpdateDateTime\" : \"2000-01-23T04:56:07.000+00:00\",\n    \"CreationDateTime\" : \"2000-01-23T04:56:07.000+00:00\",\n    \"TransactionToDateTime\" : \"2000-01-23T04:56:07.000+00:00\",\n    \"ExpirationDateTime\" : \"2000-01-23T04:56:07.000+00:00\",\n    \"Permissions\" : [ \"ReadAccountsBasic\", \"ReadAccountsBasic\" ],\n    \"ConsentId\" : \"ConsentId\",\n    \"TransactionFromDateTime\" : \"2000-01-23T04:56:07.000+00:00\"\n  }\n}", OBReadConsentResponse1.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<OBReadConsentResponse1>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<OBReadConsentResponse1>(HttpStatus.NOT_IMPLEMENTED);
    }

}
